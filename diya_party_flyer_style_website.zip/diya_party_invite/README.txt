DIYA PARTY WEBSITE — RASHI × SHRUTI × JANVI

This is the upgraded, flyer-matched version. Keep BOTH files together:
- index.html
- flyer.jpeg

PREVIEW
1. Extract the ZIP.
2. Open index.html in Chrome, Edge or Safari.
3. Click "Okay, let me in" and explore the interactive sections.

PUBLISH FREE WITH GITHUB PAGES
1. Create a new public repository on https://github.com/
2. Upload BOTH index.html and flyer.jpeg to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, select Deploy from a branch.
5. Choose branch main and folder /(root), then Save.
6. Wait for GitHub Pages to publish your link.

IMPORTANT
- The RSVP creates a shareable message; it does not save responses or automatically notify hosts.
- The countdown/time details are not included because the party time was not provided.
- The event date is set to 9 November 2026. If you mean another year, update the date in the ticket text.
- Google Fonts need an internet connection. The rest of the page runs locally.
